import { ScrollView, StyleSheet, Text, View } from 'react-native';

import { Badge, BreedMedallion, Header, Page, StatBar, WoodCard } from '@/components/game-ui';
import { BREEDS, palette, PLAYER_LEVELS } from '@/game/data';
import { money, nextLevel } from '@/game/engine';
import { useGame } from '@/game/GameContext';

const achievementCatalog = [
  'First Win',
  'First Bred Bird',
  'Spent ₨10,000 in market',
  'Won 5 competitions',
  'Reached Ustad level',
  'Owned a Sialkoti',
];

export default function RecordsScreen() {
  const { state } = useGame();
  const level = PLAYER_LEVELS.find((item) => item.level === state.player.level) ?? PLAYER_LEVELS[0];
  const next = nextLevel(state.player.xp);
  const xpProgress = next.xpRequired === level.xpRequired ? 100 : ((state.player.xp - level.xpRequired) / (next.xpRequired - level.xpRequired)) * 100;
  const bestBirds = [...state.pigeons].sort((a, b) => b.overallRating - a.overallRating).slice(0, 3);
  const breedCounts = Object.keys(BREEDS).map((breed) => ({
    breed,
    count: state.pigeons.filter((bird) => bird.breed === breed).length,
  }));
  const winRate = state.player.totalCompetitions ? (state.player.totalWins / state.player.totalCompetitions) * 100 : 0;

  return (
    <Page>
      <Header title="ریکارڈ" subtitle="RECORDS · Career ledger" right={<Badge label={level.title} />} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <WoodCard style={styles.block}>
          <Text style={styles.title}>{state.player.name || 'Player'}</Text>
          <Text style={styles.note}>{state.player.loftName || 'No loft yet'} · Joined {new Date(state.player.joinedAt).toLocaleDateString()}</Text>
          <StatBar label="XP" value={xpProgress} />
          <Text style={styles.note}>{state.player.xp} XP · Next: {next.title}</Text>
        </WoodCard>
        <WoodCard style={styles.block}>
          <Text style={styles.section}>Career Stats</Text>
          <View style={styles.grid}>
            <Metric label="Competitions" value={`${state.player.totalCompetitions}`} />
            <Metric label="Wins" value={`${state.player.totalWins}`} />
            <Metric label="Win Rate" value={`${winRate.toFixed(0)}%`} />
            <Metric label="Best Score" value={`${state.player.bestScore.toFixed(1)}h`} />
            <Metric label="Earned" value={money(state.player.totalMoneyEarned)} />
            <Metric label="Birds" value={`${state.pigeons.length}`} />
          </View>
        </WoodCard>
        <WoodCard style={styles.block}>
          <Text style={styles.section}>Best Birds</Text>
          {bestBirds.length ? bestBirds.map((bird) => (
            <View key={bird.id} style={styles.birdRow}>
              <BreedMedallion pigeon={bird} size={58} />
              <View style={{ flex: 1 }}>
                <Text style={styles.birdName}>{bird.name}</Text>
                <Text style={styles.note}>{BREEDS[bird.breed].name} · Rating {bird.overallRating.toFixed(1)}</Text>
              </View>
            </View>
          )) : <Text style={styles.note}>No birds in the loft yet.</Text>}
        </WoodCard>
        <WoodCard style={styles.block}>
          <Text style={styles.section}>Breed Ledger</Text>
          <View style={styles.ledger}>
            {breedCounts.map((item) => (
              <View key={item.breed} style={styles.ledgerItem}>
                <Text style={styles.ledgerText}>{item.breed}</Text>
                <Text style={styles.ledgerCount}>{item.count}</Text>
              </View>
            ))}
          </View>
        </WoodCard>
        <WoodCard style={styles.block}>
          <Text style={styles.section}>Achievements</Text>
          {achievementCatalog.map((achievement) => {
            const unlocked = state.achievements.includes(achievement);
            return (
              <View key={achievement} style={[styles.achievement, unlocked && styles.unlocked]}>
                <Text style={styles.achievementIcon}>{unlocked ? '◆' : '◇'}</Text>
                <Text style={[styles.achievementText, !unlocked && styles.locked]}>{achievement}</Text>
              </View>
            );
          })}
        </WoodCard>
      </ScrollView>
    </Page>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.metric}>
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.note}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  block: { marginBottom: 12 },
  title: { color: palette.goldLight, fontFamily: 'serif', fontSize: 28, fontWeight: '900' },
  section: { color: palette.goldLight, fontSize: 18, fontWeight: '900', marginBottom: 10 },
  note: { color: palette.muted, fontSize: 12, marginTop: 3 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  metric: { width: '48%', backgroundColor: palette.bg2, borderRadius: 8, padding: 12, borderWidth: 1, borderColor: palette.gold },
  metricValue: { color: palette.cream, fontSize: 18, fontWeight: '900' },
  birdRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 },
  birdName: { color: palette.cream, fontWeight: '900', fontSize: 16 },
  ledger: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  ledgerItem: { width: '48%', flexDirection: 'row', justifyContent: 'space-between', borderWidth: 1, borderColor: palette.gold, borderRadius: 6, padding: 9 },
  ledgerText: { color: palette.cream, fontSize: 12, fontWeight: '800' },
  ledgerCount: { color: palette.goldLight, fontWeight: '900' },
  achievement: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 9, opacity: 0.55 },
  unlocked: { opacity: 1 },
  achievementIcon: { color: palette.goldLight, fontSize: 18 },
  achievementText: { color: palette.cream, fontWeight: '800' },
  locked: { color: palette.muted },
});
