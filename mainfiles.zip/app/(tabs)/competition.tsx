import React from 'react';
import { Alert, FlatList, ScrollView, StyleSheet, Text, View } from 'react-native';

import { Badge, BrassButton, Header, ImagePanel, Page, PigeonCard, WoodCard } from '@/components/game-ui';
import { palette, PLAYER_LEVELS } from '@/game/data';
import { assignPrizes, competitionPrize, generateBots, getPigeonStatus, money, randomWeather, simulateCompetition } from '@/game/engine';
import { useGame } from '@/game/GameContext';
import { CompetitionResult, LeaderboardRow, Pigeon, Weather } from '@/game/types';

type Phase = 'menu' | 'select' | 'flight' | 'results';
type Outcome = {
  leaderboard: LeaderboardRow[];
  results: CompetitionResult[];
  xpEarned: number;
  moneyEarned: number;
  lostNames: string[];
  rank: number;
};

export default function CompetitionScreen() {
  const { state, runCompetition, clearLevelUp } = useGame();
  const [phase, setPhase] = React.useState<Phase>('menu');
  const [size, setSize] = React.useState(3);
  const [weather, setWeather] = React.useState<Weather>(randomWeather());
  const [selected, setSelected] = React.useState<Pigeon[]>([]);
  const [bots, setBots] = React.useState<LeaderboardRow[]>([]);
  const [outcome, setOutcome] = React.useState<Outcome | null>(null);

  const ready = state.pigeons.filter((bird) => getPigeonStatus(bird) === 'Ready');

  const startSelect = (nextSize: number) => {
    if (nextSize === 7 && state.player.level < 3) {
      Alert.alert('Locked', '7-bird muqabila unlocks at Level 3: Ustad.');
      return;
    }
    if (state.player.money < nextSize * 500) {
      Alert.alert('Entry fee needed', `You need ${money(nextSize * 500)} to enter.`);
      return;
    }
    setWeather(randomWeather());
    setSize(nextSize);
    setSelected([]);
    setBots(generateBots(state.player.level));
    setPhase('select');
  };

  const fly = () => {
    const results = simulateCompetition(selected, weather);
    const score = results.reduce((sum, result) => sum + result.hours, 0);
    const leaderboard = assignPrizes(
      [{ name: state.player.name, city: state.player.loftName, score, prize: 0, isPlayer: true }, ...bots],
      competitionPrize(size),
    );
    const playerRow = leaderboard.find((row) => row.isPlayer);
    setOutcome({
      results,
      leaderboard,
      xpEarned: Math.floor(score * 10),
      moneyEarned: playerRow?.prize ?? 0,
      lostNames: results.filter((result) => !result.returned).map((result) => result.pigeonName),
      rank: leaderboard.findIndex((row) => row.isPlayer) + 1,
    });
    setPhase('flight');
  };

  if (!state.hasSave) {
    return (
      <Page>
        <Header title="مقابلہ" subtitle="Start a new game first." />
      </Page>
    );
  }

  return (
    <Page>
      <Header title="مقابلہ" subtitle="MUQABILA · High flyer competition" right={<Badge label={money(state.player.money)} />} />
      {state.lastLevelUp ? (
        <WoodCard>
          <Text style={styles.win}>LEVEL UP · Ustad Bana Gaye!</Text>
          <Text style={styles.note}>You are now {PLAYER_LEVELS.find((item) => item.level === state.lastLevelUp)?.title}</Text>
          <BrassButton label="Mubarak" icon="sparkles" onPress={clearLevelUp} />
        </WoodCard>
      ) : null}
      {phase === 'menu' ? <Menu onSelect={startSelect} level={state.player.level} /> : null}
      {phase === 'select' ? (
        <SelectBirds
          ready={ready}
          size={size}
          weather={weather}
          selected={selected}
          onToggle={(bird) =>
            setSelected((current) =>
              current.some((item) => item.id === bird.id)
                ? current.filter((item) => item.id !== bird.id)
                : current.length < size
                  ? [...current, bird]
                  : current,
            )
          }
          onBack={() => setPhase('menu')}
          onFly={fly}
        />
      ) : null}
      {phase === 'flight' && outcome ? (
        <FlightProgress
          outcome={outcome}
          selected={selected}
          weather={weather}
          onDone={() => {
            const finalOutcome = runCompetition({ selected, weather, size, bots }, outcome);
            setOutcome(finalOutcome);
            setPhase('results');
          }}
        />
      ) : null}
      {phase === 'results' && outcome ? <Results outcome={outcome} onDone={() => setPhase('menu')} /> : null}
    </Page>
  );
}

function Menu({ onSelect, level }: { onSelect: (size: number) => void; level: number }) {
  const sizes = [3, 5, 7];
  const weather = randomWeather();
  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <WoodCard style={styles.weather}>
        <Text style={styles.title}>Today&apos;s Weather · آج کا موسم</Text>
        <Text style={styles.weatherName}>{weather.urdu} · {weather.name}</Text>
        <Text style={styles.note}>{weather.note}</Text>
      </WoodCard>
      {sizes.map((size) => (
        <WoodCard key={size} style={styles.compCard}>
          <Text style={styles.compUrdu}>{size} پرندے</Text>
          <Text style={styles.compTitle}>{size} BIRDS</Text>
          <Text style={styles.note}>Entry: {money(size * 500)} · Prize: {money(competitionPrize(size))}</Text>
          <BrassButton label={size === 7 && level < 3 ? 'Locked until Ustad' : 'Select'} icon="chevron-forward" onPress={() => onSelect(size)} />
        </WoodCard>
      ))}
    </ScrollView>
  );
}

function SelectBirds({
  ready,
  size,
  weather,
  selected,
  onToggle,
  onBack,
  onFly,
}: {
  ready: Pigeon[];
  size: number;
  weather: Weather;
  selected: Pigeon[];
  onToggle: (bird: Pigeon) => void;
  onBack: () => void;
  onFly: () => void;
}) {
  const est = selected.reduce((sum, bird) => sum + bird.flightPotential * weather.modifier, 0);
  return (
    <View style={{ flex: 1 }}>
      <WoodCard>
        <Text style={styles.title}>{weather.urdu} · {weather.name}</Text>
        <Text style={styles.note}>{weather.note}</Text>
        <Text style={styles.summary}>{selected.length}/{size} selected · Est. {est.toFixed(1)} hrs</Text>
      </WoodCard>
      <FlatList
        data={ready}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={{ justifyContent: 'space-between' }}
        contentContainerStyle={{ paddingVertical: 12, paddingBottom: 94 }}
        renderItem={({ item }) => <PigeonCard pigeon={item} selected={selected.some((bird) => bird.id === item.id)} onPress={() => onToggle(item)} />}
      />
      <View style={styles.bottomBar}>
        <BrassButton label="Back" onPress={onBack} />
        <BrassButton label="FLY THEM" icon="send" disabled={selected.length !== size} onPress={onFly} />
      </View>
    </View>
  );
}

function FlightProgress({
  outcome,
  selected,
  weather,
  onDone,
}: {
  outcome: Outcome;
  selected: Pigeon[];
  weather: Weather;
  onDone: () => void;
}) {
  const [elapsed, setElapsed] = React.useState(0);
  const [finished, setFinished] = React.useState(false);
  const longestReturned = Math.max(0, ...outcome.results.filter((result) => result.returned).map((result) => result.hours));
  const longestExpected = Math.max(3, ...selected.map((bird) => bird.flightPotential * weather.modifier));
  const duration = Math.ceil(Math.max(longestReturned, outcome.lostNames.length ? longestExpected : longestReturned, 3));
  const arrivals = outcome.results
    .filter((result) => result.returned && result.hours <= elapsed)
    .sort((a, b) => a.hours - b.hours);
  const stillFlying = outcome.results.filter((result) => result.returned && result.hours > elapsed).length + outcome.lostNames.length;
  const progress = Math.min(100, (elapsed / duration) * 100);

  React.useEffect(() => {
    setElapsed(0);
    setFinished(false);
  }, [outcome]);

  React.useEffect(() => {
    if (finished) return undefined;
    const timer = setInterval(() => {
      setElapsed((current) => {
        const next = current + 1;
        if (next >= duration) {
          clearInterval(timer);
          setFinished(true);
          setTimeout(onDone, 850);
        }
        return next;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [duration, finished, onDone]);

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <ImagePanel image="sky" style={styles.flightPanel}>
        <Text style={styles.flightTitle}>The Flight · اڑان</Text>
        <Text style={styles.birdDots}>🕊️   ·   🕊️      ·      🕊️</Text>
        <Text style={styles.flightClock}>{elapsed}s · {elapsed} flight hours</Text>
        <View style={styles.flightTrack}>
          <View style={[styles.flightFill, { width: `${Math.max(4, progress)}%` }]} />
        </View>
        <Text style={styles.note}>1 real second = 1 flight hour. Results arrive as pigeons return.</Text>
      </ImagePanel>
      <WoodCard style={styles.weather}>
        <Text style={styles.title}>Live Return Feed</Text>
        {arrivals.length ? (
          arrivals.map((result) => (
            <View key={result.pigeonId} style={styles.arrivalRow}>
              <Text style={styles.arrivalName}>{result.pigeonName}</Text>
              <Text style={styles.arrivalTime}>returned · {result.hours.toFixed(1)}h</Text>
            </View>
          ))
        ) : (
          <Text style={styles.note}>The flock is still circling high above the rooftops.</Text>
        )}
        <Text style={styles.summary}>{stillFlying > 0 ? `${stillFlying} still in the sky` : 'All returning pigeons have landed'}</Text>
      </WoodCard>
    </ScrollView>
  );
}

function Results({
  outcome,
  onDone,
}: {
  outcome: Outcome;
  onDone: () => void;
}) {
  const playerWon = outcome.rank === 1;
  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <ImagePanel image="sky" style={styles.sky}>
        <Text style={styles.flightTitle}>The Flight · اڑان</Text>
        <Text style={styles.birdDots}>🕊️   ·   🕊️      ·      🕊️</Text>
        <Text style={styles.note}>Scores were simulated with weather, stamina, height, agility, and home-return risk.</Text>
      </ImagePanel>
      {outcome.lostNames.length ? (
        <WoodCard style={styles.lossCard}>
          <Text style={styles.lossTitle}>Inna Lillahi...</Text>
          <Text style={styles.lossText}>{outcome.lostNames.join(', ')} wapas nahi aaya. The skies claimed them today.</Text>
        </WoodCard>
      ) : null}
      <WoodCard>
        <Text style={playerWon ? styles.win : styles.title}>{playerWon ? 'مبارک ہو! You Won!' : 'Muqabila Results'}</Text>
        {outcome.leaderboard.map((row, index) => (
          <View key={`${row.name}-${index}`} style={[styles.leaderRow, row.isPlayer && styles.playerRow]}>
            <Text style={styles.rank}>#{index + 1}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowName}>{row.name}</Text>
              <Text style={styles.note}>{row.city}</Text>
            </View>
            <Text style={styles.score}>{row.score.toFixed(1)}h</Text>
            <Text style={styles.prize}>{row.prize ? money(row.prize) : '--'}</Text>
          </View>
        ))}
        <Text style={styles.summary}>XP +{outcome.xpEarned} · Money +{money(outcome.moneyEarned)}</Text>
        <BrassButton label="Back to Menu" icon="return-up-back" onPress={onDone} />
      </WoodCard>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  title: { color: palette.goldLight, fontSize: 18, fontWeight: '900' },
  note: { color: palette.muted, fontSize: 12, marginTop: 4 },
  weather: { marginBottom: 12 },
  weatherName: { color: palette.cream, fontSize: 20, fontWeight: '900', marginTop: 8 },
  compCard: { marginBottom: 12, gap: 8 },
  compUrdu: { color: palette.goldLight, fontFamily: 'serif', fontSize: 25 },
  compTitle: { color: palette.cream, fontSize: 22, fontWeight: '900' },
  summary: { color: palette.cream, fontWeight: '900', marginVertical: 12 },
  bottomBar: { position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: palette.bg, paddingTop: 10, flexDirection: 'row', gap: 8 },
  flightPanel: { marginBottom: 12, minHeight: 230 },
  sky: { marginBottom: 12, minHeight: 150 },
  flightTitle: { color: palette.cream, fontWeight: '900', fontSize: 24 },
  flightClock: { color: palette.goldLight, fontSize: 20, fontWeight: '900', marginTop: 8 },
  flightTrack: { height: 9, backgroundColor: 'rgba(26,17,8,0.78)', borderRadius: 99, marginTop: 14, overflow: 'hidden' },
  flightFill: { height: '100%', backgroundColor: palette.goldLight },
  birdDots: { color: palette.cream, fontSize: 28, marginVertical: 12 },
  arrivalRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, borderBottomWidth: 1, borderBottomColor: palette.bg2, paddingVertical: 10 },
  arrivalName: { color: palette.cream, fontWeight: '900', flex: 1 },
  arrivalTime: { color: palette.green, fontWeight: '800' },
  lossCard: { borderColor: palette.red, marginBottom: 12 },
  lossTitle: { color: palette.red, fontSize: 21, fontWeight: '900' },
  lossText: { color: palette.cream, lineHeight: 20, marginTop: 6 },
  win: { color: palette.goldLight, fontSize: 23, fontWeight: '900' },
  leaderRow: { flexDirection: 'row', alignItems: 'center', gap: 10, borderBottomWidth: 1, borderBottomColor: palette.bg2, paddingVertical: 10 },
  playerRow: { backgroundColor: 'rgba(232,184,75,0.12)' },
  rank: { color: palette.goldLight, width: 34, fontWeight: '900' },
  rowName: { color: palette.cream, fontWeight: '900' },
  score: { color: palette.cream, width: 56, textAlign: 'right', fontVariant: ['tabular-nums'] },
  prize: { color: palette.goldLight, width: 74, textAlign: 'right', fontWeight: '800' },
});
