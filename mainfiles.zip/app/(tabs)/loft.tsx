import React from 'react';
import { Alert, FlatList, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';

import { Badge, Header, ImagePanel, Page, PigeonCard, PigeonDetailSheet, WoodCard } from '@/components/game-ui';
import { palette } from '@/game/data';
import { breedingMs, getPigeonStatus, incubationMs, money } from '@/game/engine';
import { useGame } from '@/game/GameContext';
import { Pigeon } from '@/game/types';

const filters = ['All', 'Males', 'Females', 'Ready', 'Breeding', 'Juvenile'];

export default function LoftScreen() {
  const { state, sellPigeon, renamePigeon, pairPigeons } = useGame();
  const [filter, setFilter] = React.useState('All');
  const [selected, setSelected] = React.useState<Pigeon | null>(null);
  const [pairSource, setPairSource] = React.useState<Pigeon | null>(null);
  const [now, setNow] = React.useState(Date.now());

  React.useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const activePairs = state.pigeons.filter((bird) => bird.isPaired && bird.gender === 'male');
  const birds = state.pigeons.filter((bird) => {
    const status = getPigeonStatus(bird);
    if (filter === 'Males') return bird.gender === 'male';
    if (filter === 'Females') return bird.gender === 'female';
    if (filter === 'Ready') return status === 'Ready';
    if (filter === 'Breeding') return status === 'Breeding' || status === 'Incubating';
    if (filter === 'Juvenile') return status === 'Juvenile';
    return true;
  });

  const requestPair = (bird: Pigeon) => {
    if (!pairSource) {
      setPairSource(bird);
      setSelected(null);
      return;
    }
    if (pairSource.gender === bird.gender) {
      Alert.alert('Opposite pair needed', 'Select one male and one female for breeding.');
      return;
    }
    const male = pairSource.gender === 'male' ? pairSource : bird;
    const female = pairSource.gender === 'female' ? pairSource : bird;
    pairPigeons(male.id, female.id);
    setPairSource(null);
    setSelected(null);
  };

  const listHeader = (
    <View style={styles.listHeader}>
      <Header
        title={`${state.player.loftName || 'Loft'}`}
        subtitle={`${state.pigeons.length} pigeons Â· ${activePairs.length} breeding pairs`}
        right={<Badge label={money(state.player.money)} />}
      />
      <ImagePanel image="loft" style={styles.hero}>
        <Text style={styles.heroTitle}>Ø¢Ù¾ Ú©Ø§ Ú©Ø¨ÙˆØªØ± Ø®Ø§Ù†Û</Text>
        <Text style={styles.heroNote}>Keep the loft strong, rested, and ready for the sky.</Text>
      </ImagePanel>
      {pairSource ? (
        <WoodCard>
          <Text style={styles.notice}>Pairing selected: {pairSource.name}. Tap an opposite gender ready bird to confirm.</Text>
        </WoodCard>
      ) : null}
      {activePairs.length ? (
        <WoodCard>
          <Text style={styles.sectionTitle}>Breeding Corner Â· Ø§ÙØ²Ø§Ø¦Ø´</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
            {activePairs.map((male) => {
              const female = state.pigeons.find((bird) => bird.id === male.pairedWithId);
              const target = male.isBreeding ? (male.breedingStartTime ?? now) + breedingMs : male.hatchTime ?? now + incubationMs;
              return (
                <View key={male.id} style={styles.pairCard}>
                  <Text style={styles.pairText}>â™‚ {male.name}</Text>
                  <Text style={styles.heart}>â™¥</Text>
                  <Text style={styles.pairText}>â™€ {female?.name ?? 'Mate'}</Text>
                  <Text style={styles.timer}>{male.isBreeding ? 'Eggs in' : 'Hatch in'} {formatLeft(target - now)}</Text>
                </View>
              );
            })}
          </ScrollView>
        </WoodCard>
      ) : null}
      <View style={styles.filters}>
        {filters.map((item) => (
          <Pressable key={item} onPress={() => setFilter(item)} style={[styles.filter, filter === item && styles.filterActive]}>
            <Text style={styles.filterText}>{item}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );

  return (
    <Page>
      <FlatList
        data={birds}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={{ justifyContent: 'space-between' }}
        contentContainerStyle={{ paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={listHeader}
        renderItem={({ item }) => (
          <PigeonCard
            pigeon={item}
            selected={pairSource?.id === item.id}
            onPress={() => {
              if (pairSource && pairSource.id !== item.id && getPigeonStatus(item) === 'Ready') requestPair(item);
              else setSelected(item);
            }}
          />
        )}
      />
      <PigeonDetailSheet
        pigeon={selected}
        visible={Boolean(selected)}
        onClose={() => setSelected(null)}
        onRename={(name) => selected && renamePigeon(selected.id, name)}
        onPair={() => selected && requestPair(selected)}
        onSell={() => {
          if (!selected) return;
          Alert.alert('Permanent sale', `Sell ${selected.name} for ${money(selected.marketValue)}?`, [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Sell', style: 'destructive', onPress: () => { sellPigeon(selected.id); setSelected(null); } },
          ]);
        }}
      />
    </Page>
  );
}

function formatLeft(ms: number) {
  const safe = Math.max(0, ms);
  return `${String(Math.floor(safe / 60000)).padStart(2, '0')}:${String(Math.floor((safe % 60000) / 1000)).padStart(2, '0')}`;
}

const styles = StyleSheet.create({
  listHeader: { gap: 14, marginBottom: 12 },
  filters: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  hero: { minHeight: 118 },
  heroTitle: { color: palette.goldLight, fontFamily: 'serif', fontSize: 26, fontWeight: '900' },
  heroNote: { color: palette.cream, marginTop: 6, fontWeight: '700' },
  filter: { borderWidth: 1, borderColor: palette.muted, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 7 },
  filterActive: { borderColor: palette.goldLight, backgroundColor: palette.bg2 },
  filterText: { color: palette.cream, fontWeight: '800', fontSize: 12 },
  sectionTitle: { color: palette.goldLight, fontWeight: '900', fontSize: 16, marginBottom: 10 },
  notice: { color: palette.cream, lineHeight: 19 },
  pairCard: { width: 160, borderWidth: 1, borderColor: palette.gold, borderRadius: 8, padding: 10, backgroundColor: palette.bg2 },
  pairText: { color: palette.cream, fontWeight: '800' },
  heart: { color: palette.red, fontSize: 20, textAlign: 'center' },
  timer: { color: palette.goldLight, marginTop: 6, fontWeight: '900' },
});
