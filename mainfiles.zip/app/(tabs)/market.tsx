import React from 'react';
import { Alert, FlatList, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';

import { Badge, BrassButton, BreedMedallion, Header, ImagePanel, Page, StatBar, WoodCard } from '@/components/game-ui';
import { BREEDS, palette } from '@/game/data';
import { marketMs, money, starText } from '@/game/engine';
import { useGame } from '@/game/GameContext';
import { Pigeon } from '@/game/types';

const filters = ['All', 'Male', 'Female', 'Common', 'Uncommon', 'Rare'];

export default function MarketScreen() {
  const { state, refreshMarket, buyPigeon } = useGame();
  const [filter, setFilter] = React.useState('All');
  const [now, setNow] = React.useState(Date.now());
  const [haggle, setHaggle] = React.useState<Pigeon | null>(null);
  const [offer, setOffer] = React.useState('');

  React.useEffect(() => {
    if (!state.hasSave) return;
    if (!state.market.nextRefresh || Date.now() >= state.market.nextRefresh) refreshMarket();
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [refreshMarket, state.hasSave, state.market.nextRefresh]);

  const left = Math.max(0, (state.market.nextRefresh ?? Date.now() + marketMs) - now);
  const countdown = `${String(Math.floor(left / 60000)).padStart(2, '0')}:${String(Math.floor((left % 60000) / 1000)).padStart(2, '0')}`;
  const birds = state.market.birds.filter((bird) => {
    if (filter === 'Male') return bird.gender === 'male';
    if (filter === 'Female') return bird.gender === 'female';
    if (['Common', 'Uncommon', 'Rare'].includes(filter)) return BREEDS[bird.breed].rarity === filter;
    return true;
  });

  const acceptOffer = () => {
    if (!haggle) return;
    const offered = Number(offer);
    const ratio = offered / haggle.purchasePrice;
    const accepted = ratio >= 0.8 || (ratio >= 0.6 && Math.random() < 0.5);
    if (!accepted) {
      Alert.alert('Seller refused', 'The mandi ustad shakes his head. Offer a little more respect.');
      return;
    }
    buyPigeon(haggle.id, offered);
    setHaggle(null);
    setOffer('');
  };

  if (!state.hasSave) {
    return (
      <Page>
        <Header title="منڈی" subtitle="Start a new game first." />
      </Page>
    );
  }

  return (
    <Page>
      <Header title="منڈی" subtitle={`MANDI · Market refreshes in ${countdown}`} right={<Badge label={money(state.player.money)} />} />
      <ImagePanel image="market" style={styles.hero}>
        <Text style={styles.heroTitle}>پرندوں کی منڈی</Text>
        <Text style={styles.heroNote}>Fresh birds, hard bargaining, and old-city reputation.</Text>
      </ImagePanel>
      <View style={styles.filters}>
        {filters.map((item) => (
          <Pressable key={item} onPress={() => setFilter(item)} style={[styles.filter, filter === item && styles.filterActive]}>
            <Text style={styles.filterText}>{item}</Text>
          </Pressable>
        ))}
      </View>
      <FlatList
        data={birds}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 24 }}
        renderItem={({ item }) => <MarketCard bird={item} onBuy={() => buyPigeon(item.id)} onHaggle={() => { setHaggle(item); setOffer(String(Math.floor(item.purchasePrice * 0.75))); }} />}
      />
      <Modal transparent animationType="slide" visible={Boolean(haggle)} onRequestClose={() => setHaggle(null)}>
        <Pressable style={styles.scrim} onPress={() => setHaggle(null)} />
        <WoodCard style={styles.haggleSheet}>
          <Text style={styles.title}>Haggle with the seller</Text>
          <Text style={styles.note}>{haggle?.name} asking price: {haggle ? money(haggle.purchasePrice) : ''}</Text>
          <TextInput keyboardType="numeric" value={offer} onChangeText={setOffer} style={styles.input} />
          <Text style={styles.note}>80% or above is accepted. 60-79% is a coin toss.</Text>
          <View style={styles.actions}>
            <BrassButton label="Make Offer" icon="chatbubble" onPress={acceptOffer} />
            <BrassButton label="Cancel" onPress={() => setHaggle(null)} />
          </View>
        </WoodCard>
      </Modal>
    </Page>
  );
}

function MarketCard({ bird, onBuy, onHaggle }: { bird: Pigeon; onBuy: () => void; onHaggle: () => void }) {
  const breed = BREEDS[bird.breed];
  return (
    <WoodCard style={[styles.marketCard, bird.sold && styles.sold]}>
      <BreedMedallion pigeon={bird} size={86} />
      <View style={{ flex: 1 }}>
        <View style={styles.row}>
          <Text style={styles.name}>{bird.name}</Text>
          <Badge label={breed.rarity} tone={breed.rarity === 'Rare' ? 'red' : breed.rarity === 'Uncommon' ? 'sky' : 'gold'} />
        </View>
        <Text style={styles.note}>{breed.name} {bird.gender === 'male' ? '♂' : '♀'} · {breed.urduName}</Text>
        <Text style={styles.stars}>{starText(bird.overallRating)}</Text>
        <StatBar label="STM" value={bird.stamina} />
        <StatBar label="HGT" value={bird.flyHeight} />
        <StatBar label="RTN" value={bird.homeReturn} />
        <View style={styles.buyRow}>
          <Text style={styles.price}>{bird.sold ? 'SOLD' : money(bird.purchasePrice)}</Text>
          <BrassButton label="Buy" icon="cash" onPress={onBuy} disabled={bird.sold} />
          <BrassButton label="Haggle" icon="chatbubbles" onPress={onHaggle} disabled={bird.sold} />
        </View>
      </View>
    </WoodCard>
  );
}

const styles = StyleSheet.create({
  filters: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  hero: { minHeight: 128 },
  heroTitle: { color: palette.goldLight, fontFamily: 'serif', fontSize: 28, fontWeight: '900' },
  heroNote: { color: palette.cream, marginTop: 6, fontWeight: '700' },
  filter: { borderWidth: 1, borderColor: palette.muted, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 7 },
  filterActive: { borderColor: palette.goldLight, backgroundColor: palette.bg2 },
  filterText: { color: palette.cream, fontWeight: '800', fontSize: 12 },
  marketCard: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  sold: { opacity: 0.48 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  name: { color: palette.cream, fontSize: 18, fontWeight: '900', flex: 1 },
  title: { color: palette.goldLight, fontSize: 22, fontWeight: '900' },
  note: { color: palette.muted, fontSize: 12, marginTop: 4 },
  stars: { color: palette.goldLight, marginTop: 6 },
  buyRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 12, flexWrap: 'wrap' },
  price: { color: palette.goldLight, fontSize: 18, fontWeight: '900', marginRight: 'auto' },
  scrim: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)' },
  haggleSheet: { margin: 16, marginTop: 'auto' },
  input: { borderWidth: 1, borderColor: palette.gold, borderRadius: 6, color: palette.cream, backgroundColor: palette.bg, padding: 12, marginVertical: 12 },
  actions: { flexDirection: 'row', gap: 8 },
});
