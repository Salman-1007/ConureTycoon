import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';

import { Badge, BrassButton, Header, ImagePanel, Page, WoodCard } from '@/components/game-ui';
import { palette, PLAYER_LEVELS } from '@/game/data';
import { money, nextLevel } from '@/game/engine';
import { useGame } from '@/game/GameContext';

export default function HomeScreen() {
  const { state, loading, startNewGame } = useGame();
  const [setup, setSetup] = React.useState(false);
  const [name, setName] = React.useState('Irfan');
  const [loftName, setLoftName] = React.useState('Sialkot da Sher Loft');
  const [startMoney, setStartMoney] = React.useState(10000);

  if (loading) {
    return (
      <Page>
        <View style={styles.center}>
          <Text style={styles.logoUrdu}>کبوتر باز</Text>
          <Text style={styles.logo}>KABOOTAR BAAZ</Text>
        </View>
      </Page>
    );
  }

  if (!state.hasSave || setup) {
    return (
      <Page>
        <ImagePanel image="rooftop" style={styles.splashSky}>
          <Text style={styles.feather}>︿ ︿ ︿</Text>
          <Text style={styles.logoUrdu}>کبوتر باز</Text>
          <Text style={styles.logo}>KABOOTAR BAAZ</Text>
          <Text style={styles.tagline}>Breed the Best. Fly the Highest. Rule the Skies.</Text>
        </ImagePanel>
        <WoodCard>
          <Text style={styles.cardTitle}>Apna Naam Likhein</Text>
          <TextInput value={name} onChangeText={setName} style={styles.input} placeholderTextColor={palette.muted} />
          <Text style={styles.cardTitle}>Apna Loft Ka Naam</Text>
          <TextInput value={loftName} onChangeText={setLoftName} style={styles.input} placeholderTextColor={palette.muted} />
          <Text style={styles.cardTitle}>Shuru Ki Raqam</Text>
          <View style={styles.moneyGrid}>
            {[5000, 10000, 20000, 50000].map((amount) => (
              <Pressable key={amount} onPress={() => setStartMoney(amount)} style={[styles.moneyOption, startMoney === amount && styles.moneyActive]}>
                <Text style={styles.moneyOptionText}>{money(amount)}</Text>
              </Pressable>
            ))}
          </View>
          <BrassButton
            label="Start Playing"
            icon="play"
            onPress={() => {
              startNewGame({ name, loftName, money: startMoney });
              setSetup(false);
            }}
          />
        </WoodCard>
        {state.hasSave ? <BrassButton label="Continue Saved Game" icon="return-up-forward" onPress={() => setSetup(false)} /> : null}
      </Page>
    );
  }

  const level = PLAYER_LEVELS.find((item) => item.level === state.player.level) ?? PLAYER_LEVELS[0];
  const next = nextLevel(state.player.xp);
  const xpBase = level.xpRequired;
  const xpProgress = next.xpRequired === xpBase ? 1 : (state.player.xp - xpBase) / (next.xpRequired - xpBase);
  const cards = [
    { title: 'MARKET', urdu: 'منڈی', icon: 'storefront', note: `Buy new birds · ${state.market.birds.filter((bird) => !bird.sold).length} available`, href: '/market' },
    { title: 'LOFT', urdu: 'کبوتر خانہ', icon: 'grid', note: `Your pigeons: ${state.pigeons.length}`, href: '/loft' },
    { title: 'COMPETITION', urdu: 'مقابلہ', icon: 'trophy', note: 'Next flight ready', href: '/competition' },
    { title: 'RECORDS', urdu: 'ریکارڈ', icon: 'document-text', note: `${state.achievements.length} achievements`, href: '/records' },
  ] as const;

  return (
    <Page>
      <Header
        title="چھت والا اڈہ"
        subtitle={`${state.player.name} · ${level.title} ${level.urdu}`}
        right={<Badge label={money(state.player.money)} />}
      />
      <ScrollView showsVerticalScrollIndicator={false}>
        <ImagePanel image="rooftop" style={styles.hubHero}>
          <Text style={styles.logoUrduSmall}>کبوتر باز</Text>
          <Text style={styles.hubTitle}>{state.player.loftName}</Text>
          <View style={styles.xpTrack}><View style={[styles.xpFill, { width: `${Math.max(4, xpProgress * 100)}%` }]} /></View>
          <Text style={styles.tagline}>{state.player.xp} XP · Next title: {next.title}</Text>
        </ImagePanel>
        <View style={styles.navGrid}>
          {cards.map((card) => (
            <Pressable key={card.title} onPress={() => router.push(card.href)} style={styles.navCard}>
              <Ionicons name={card.icon} size={32} color={palette.goldLight} />
              <Text style={styles.navUrdu}>{card.urdu}</Text>
              <Text style={styles.navTitle}>{card.title}</Text>
              <Text style={styles.navNote}>{card.note}</Text>
            </Pressable>
          ))}
        </View>
        <WoodCard>
          <View style={styles.statsRow}>
            <Stat label="Birds" value={`${state.pigeons.length}`} />
            <Stat label="Wins" value={`${state.player.totalWins}`} />
            <Stat label="Best" value={`${state.player.bestScore.toFixed(1)}h`} />
          </View>
        </WoodCard>
        <BrassButton label="New Game" icon="refresh" onPress={() => setSetup(true)} />
      </ScrollView>
    </Page>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <View style={{ flex: 1, alignItems: 'center' }}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.navNote}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  splashSky: {
    minHeight: 280,
  },
  feather: {
    position: 'absolute',
    top: 26,
    color: 'rgba(245,230,200,0.55)',
    fontSize: 44,
  },
  logoUrdu: {
    color: palette.goldLight,
    fontFamily: 'serif',
    fontSize: 54,
    fontWeight: '900',
  },
  logoUrduSmall: {
    color: palette.goldLight,
    fontFamily: 'serif',
    fontSize: 34,
    fontWeight: '900',
  },
  logo: {
    color: palette.cream,
    fontFamily: 'serif',
    fontSize: 27,
    fontWeight: '900',
  },
  tagline: {
    color: palette.cream,
    marginTop: 8,
    textAlign: 'center',
  },
  cardTitle: {
    color: palette.goldLight,
    fontWeight: '900',
    marginTop: 8,
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: palette.gold,
    borderRadius: 6,
    color: palette.cream,
    backgroundColor: palette.bg,
    padding: 12,
    marginBottom: 8,
  },
  moneyGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  moneyOption: {
    width: '48%',
    borderWidth: 1,
    borderColor: palette.muted,
    borderRadius: 6,
    padding: 12,
    alignItems: 'center',
  },
  moneyActive: {
    borderColor: palette.goldLight,
    backgroundColor: palette.bg2,
  },
  moneyOptionText: {
    color: palette.cream,
    fontWeight: '800',
  },
  hubHero: {
    minHeight: 150,
    marginBottom: 14,
  },
  hubTitle: {
    color: palette.cream,
    fontSize: 24,
    fontWeight: '900',
  },
  xpTrack: {
    height: 8,
    backgroundColor: palette.bg,
    borderRadius: 8,
    marginTop: 16,
    overflow: 'hidden',
  },
  xpFill: {
    height: '100%',
    backgroundColor: palette.goldLight,
  },
  navGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  navCard: {
    width: '48%',
    minHeight: 154,
    backgroundColor: palette.card,
    borderWidth: 1.5,
    borderColor: palette.gold,
    borderRadius: 8,
    padding: 14,
    marginBottom: 12,
    gap: 8,
  },
  navUrdu: {
    color: palette.goldLight,
    fontFamily: 'serif',
    fontSize: 20,
  },
  navTitle: {
    color: palette.cream,
    fontWeight: '900',
    fontSize: 16,
  },
  navNote: {
    color: palette.muted,
    fontSize: 12,
  },
  statsRow: {
    flexDirection: 'row',
  },
  statValue: {
    color: palette.goldLight,
    fontWeight: '900',
    fontSize: 20,
  },
});
