import { BreedKey } from './types';

export const pigeonImages: Partial<Record<BreedKey, number>> = {
  CheenaChapra: require('@/assets/images/pigeons/cheena_chapra.jfif'),
  Golden: require('@/assets/images/pigeons/golden.jfif'),
  Kalsira: require('@/assets/images/pigeons/kalsira.jfif'),
  Kamghar: require('@/assets/images/pigeons/kamghar.jfif'),
  Lahori: require('@/assets/images/pigeons/lahori.jfif'),
  Lakha: require('@/assets/images/pigeons/lakha.jfif'),
  Qasoori: require('@/assets/images/pigeons/qasoori.jfif'),
  Salar: require('@/assets/images/pigeons/salar.jfif'),
  Sialkoti: require('@/assets/images/pigeons/sialkoti.jfif'),
  Teddy: require('@/assets/images/pigeons/teddy.jfif'),
};

export const backgroundImages = {
  loft: require('@/assets/images/backgrounds/loft_bg.jfif'),
  market: require('@/assets/images/backgrounds/market_bg.jfif'),
  rooftop: require('@/assets/images/backgrounds/rooftop_lahore.jfif'),
  sky: require('@/assets/images/backgrounds/sky_bg.jfif'),
};
