import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, PropsWithChildren, useContext, useEffect, useMemo, useReducer } from 'react';

import { SAVE_KEY } from './data';
import {
  assignPrizes,
  competitionPrize,
  defaultSaveState,
  generateMarket,
  generatePigeonFromBreed,
  getLevel,
  id,
  recoverTimers,
  simulateCompetition,
} from './engine';
import { BreedKey, GameState, LeaderboardRow, Pigeon, Weather } from './types';

type SetupPayload = { name: string; loftName: string; money: number };
type CompetitionPayload = { selected: Pigeon[]; weather: Weather; size: number; bots: LeaderboardRow[] };
type CompetitionOutcome = {
  results: ReturnType<typeof simulateCompetition>;
  leaderboard: LeaderboardRow[];
  xpEarned: number;
  moneyEarned: number;
  lostNames: string[];
  rank: number;
};

type Action =
  | { type: 'hydrate'; state: GameState }
  | { type: 'newGame'; payload: SetupPayload }
  | { type: 'refreshMarket' }
  | { type: 'buy'; id: string; price?: number }
  | { type: 'sell'; id: string }
  | { type: 'rename'; id: string; name: string }
  | { type: 'pair'; maleId: string; femaleId: string }
  | { type: 'recoverTimers' }
  | { type: 'competition'; payload: CompetitionPayload; outcome: CompetitionOutcome }
  | { type: 'clearLevelUp' }
  | { type: 'toggleSound' };

type GameContextValue = {
  state: GameState;
  loading: boolean;
  startNewGame: (payload: SetupPayload) => void;
  refreshMarket: () => void;
  buyPigeon: (pigeonId: string, price?: number) => void;
  sellPigeon: (pigeonId: string) => void;
  renamePigeon: (pigeonId: string, name: string) => void;
  pairPigeons: (maleId: string, femaleId: string) => void;
  runCompetition: (payload: CompetitionPayload, preparedOutcome?: CompetitionOutcome) => CompetitionOutcome;
  clearLevelUp: () => void;
  toggleSound: () => void;
};

const GameContext = createContext<GameContextValue | null>(null);

function addAchievement(list: string[], achievement: string) {
  return list.includes(achievement) ? list : [...list, achievement];
}

function reducer(state: GameState, action: Action): GameState {
  switch (action.type) {
    case 'hydrate':
      return { ...recoverTimers(action.state), hasSave: true };
    case 'newGame': {
      const starterBreeds: BreedKey[] = ['Lahori', 'Teddy', 'Lakha'];
      const starters = starterBreeds.map((breed, index) =>
        generatePigeonFromBreed(breed, index === 1 ? 'female' : 'male', false),
      );
      return {
        ...defaultSaveState(),
        hasSave: true,
        player: {
          ...defaultSaveState().player,
          name: action.payload.name.trim() || 'Ustad',
          loftName: action.payload.loftName.trim() || 'Walled City Loft',
          money: action.payload.money,
          joinedAt: Date.now(),
        },
        pigeons: starters,
        market: generateMarket(1),
      };
    }
    case 'refreshMarket':
      return { ...state, market: generateMarket(state.player.level) };
    case 'buy': {
      const bird = state.market.birds.find((item) => item.id === action.id);
      if (!bird || bird.sold) return state;
      const price = action.price ?? bird.purchasePrice;
      if (state.player.money < price) return state;
      const owned = { ...bird, sold: false, purchasePrice: price, isInLoft: true, id: id('owned') };
      const achievements = bird.breed === 'Sialkoti' ? addAchievement(state.achievements, 'Owned a Sialkoti') : state.achievements;
      return {
        ...state,
        player: { ...state.player, money: state.player.money - price, marketSpent: state.player.marketSpent + price },
        market: { ...state.market, birds: state.market.birds.map((item) => (item.id === action.id ? { ...item, sold: true } : item)) },
        pigeons: [...state.pigeons, owned],
        achievements: state.player.marketSpent + price >= 10000 ? addAchievement(achievements, 'Spent ₨10,000 in market') : achievements,
      };
    }
    case 'sell': {
      const bird = state.pigeons.find((item) => item.id === action.id);
      if (!bird) return state;
      return {
        ...state,
        player: { ...state.player, money: state.player.money + bird.marketValue, totalMoneyEarned: state.player.totalMoneyEarned + bird.marketValue },
        pigeons: state.pigeons.filter((item) => item.id !== action.id),
      };
    }
    case 'rename':
      return { ...state, pigeons: state.pigeons.map((bird) => (bird.id === action.id ? { ...bird, name: action.name || bird.name } : bird)) };
    case 'pair': {
      const now = Date.now();
      return {
        ...state,
        pigeons: state.pigeons.map((bird) => {
          if (bird.id === action.maleId) {
            return { ...bird, isPaired: true, pairedWithId: action.femaleId, isBreeding: true, breedingStartTime: now };
          }
          if (bird.id === action.femaleId) {
            return { ...bird, isPaired: true, pairedWithId: action.maleId, isBreeding: true, breedingStartTime: now };
          }
          return bird;
        }),
      };
    }
    case 'recoverTimers':
      {
        const recovered = recoverTimers(state);
        return recovered.pigeons.length > state.pigeons.length
          ? { ...recovered, achievements: addAchievement(recovered.achievements, 'First Bred Bird') }
          : recovered;
      }
    case 'competition': {
      const { outcome, payload } = action;
      const playerWon = outcome.rank === 1;
      const oldLevel = state.player.level;
      const newXp = state.player.xp + outcome.xpEarned;
      const newLevel = getLevel(newXp).level;
      let achievements = state.achievements;
      if (playerWon) achievements = addAchievement(achievements, 'First Win');
      if (playerWon && state.player.totalWins + 1 >= 5) achievements = addAchievement(achievements, 'Won 5 competitions');
      if (newLevel >= 3) achievements = addAchievement(achievements, 'Reached Ustad level');
      const winners = new Set(outcome.results.filter((result) => result.returned).map((result) => result.pigeonId));
      const lost = new Set(outcome.results.filter((result) => !result.returned).map((result) => result.pigeonId));
      return {
        ...state,
        player: {
          ...state.player,
          money: state.player.money - payload.size * 500 + outcome.moneyEarned,
          xp: newXp,
          level: newLevel,
          totalCompetitions: state.player.totalCompetitions + 1,
          totalWins: state.player.totalWins + (playerWon ? 1 : 0),
          bestScore: Math.max(state.player.bestScore, outcome.leaderboard.find((row) => row.isPlayer)?.score ?? 0),
          totalMoneyEarned: state.player.totalMoneyEarned + outcome.moneyEarned,
        },
        pigeons: state.pigeons
          .filter((bird) => !lost.has(bird.id))
          .map((bird) => {
            const result = outcome.results.find((entry) => entry.pigeonId === bird.id);
            const competed = Boolean(result);
            return {
              ...bird,
              age: competed ? bird.age + 1 : bird.age,
              juvenileUntilCompetitions: Math.max(0, bird.juvenileUntilCompetitions - 1),
              competitionsEntered: competed ? bird.competitionsEntered + 1 : bird.competitionsEntered,
              competitionsWon: competed && playerWon && winners.has(bird.id) ? bird.competitionsWon + 1 : bird.competitionsWon,
              totalFlightHours: competed ? bird.totalFlightHours + (result?.hours ?? 0) : bird.totalFlightHours,
              competitionScore: competed ? bird.competitionScore + (result?.hours ?? 0) : bird.competitionScore,
            };
          }),
        achievements,
        lastLevelUp: newLevel > oldLevel ? newLevel : state.lastLevelUp,
      };
    }
    case 'clearLevelUp':
      return { ...state, lastLevelUp: null };
    case 'toggleSound':
      return { ...state, settings: { ...state.settings, soundEnabled: !state.settings.soundEnabled } };
    default:
      return state;
  }
}

export function GameProvider({ children }: PropsWithChildren) {
  const [state, dispatch] = useReducer(reducer, undefined, defaultSaveState);
  const [loading, setLoading] = React.useState(true);

  useEffect(() => {
    AsyncStorage.getItem(SAVE_KEY)
      .then((raw) => {
        if (raw) dispatch({ type: 'hydrate', state: JSON.parse(raw) });
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!loading && state.hasSave) AsyncStorage.setItem(SAVE_KEY, JSON.stringify(state));
  }, [loading, state]);

  useEffect(() => {
    const interval = setInterval(() => dispatch({ type: 'recoverTimers' }), 1000);
    return () => clearInterval(interval);
  }, []);

  const value = useMemo<GameContextValue>(
    () => ({
      state,
      loading,
      startNewGame: (payload) => dispatch({ type: 'newGame', payload }),
      refreshMarket: () => dispatch({ type: 'refreshMarket' }),
      buyPigeon: (pigeonId, price) => dispatch({ type: 'buy', id: pigeonId, price }),
      sellPigeon: (pigeonId) => dispatch({ type: 'sell', id: pigeonId }),
      renamePigeon: (pigeonId, name) => dispatch({ type: 'rename', id: pigeonId, name }),
      pairPigeons: (maleId, femaleId) => dispatch({ type: 'pair', maleId, femaleId }),
      runCompetition: (payload, preparedOutcome) => {
        const outcome =
          preparedOutcome ??
          (() => {
            const results = simulateCompetition(payload.selected, payload.weather);
            const score = results.reduce((sum, result) => sum + result.hours, 0);
            const rows = assignPrizes(
              [{ name: state.player.name, city: state.player.loftName, score, prize: 0, isPlayer: true }, ...payload.bots],
              competitionPrize(payload.size),
            );
            const playerRow = rows.find((row) => row.isPlayer);
            return {
              results,
              leaderboard: rows,
              xpEarned: Math.floor(score * 10),
              moneyEarned: playerRow?.prize ?? 0,
              lostNames: results.filter((result) => !result.returned).map((result) => result.pigeonName),
              rank: rows.findIndex((row) => row.isPlayer) + 1,
            };
          })();
        dispatch({ type: 'competition', payload, outcome });
        return outcome;
      },
      clearLevelUp: () => dispatch({ type: 'clearLevelUp' }),
      toggleSound: () => dispatch({ type: 'toggleSound' }),
    }),
    [loading, state],
  );

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGame() {
  const context = useContext(GameContext);
  if (!context) throw new Error('useGame must be used inside GameProvider');
  return context;
}
