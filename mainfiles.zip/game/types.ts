export type Gender = 'male' | 'female';
export type Rarity = 'Common' | 'Uncommon' | 'Rare';
export type ScreenMode = 'start' | 'setup' | 'hub';

export type BreedKey =
  | 'Teddy'
  | 'Sialkoti'
  | 'Qasoori'
  | 'Lahori'
  | 'Kalsira'
  | 'Kamghar'
  | 'Golden'
  | 'CheenaChapra'
  | 'Lakha'
  | 'Salar';

export type StatKey = 'stamina' | 'flyHeight' | 'homeReturn' | 'agility' | 'heatResistance';

export type Pigeon = {
  id: string;
  name: string;
  breed: BreedKey;
  gender: Gender;
  age: number;
  generation: number;
  isHomeBred: boolean;
  stamina: number;
  flyHeight: number;
  homeReturn: number;
  agility: number;
  heatResistance: number;
  overallRating: number;
  flightPotential: number;
  competitionScore: number;
  isInLoft: boolean;
  isPaired: boolean;
  pairedWithId: string | null;
  isBreeding: boolean;
  breedingStartTime: number | null;
  isIncubating: boolean;
  eggLaidTime: number | null;
  hatchTime: number | null;
  juvenileUntilCompetitions: number;
  competitionsEntered: number;
  competitionsWon: number;
  totalFlightHours: number;
  plumageColor: string;
  eyeColor: string;
  purchasePrice: number;
  marketValue: number;
  fatherBreed?: BreedKey;
  motherBreed?: BreedKey;
  sold?: boolean;
};

export type Breed = {
  name: string;
  urduName: string;
  origin: string;
  rarity: Rarity;
  basePrice: { min: number; max: number };
  description: string;
  baseStats: Record<StatKey, number>;
  maxFlightHours: { min: number; max: number };
  color: string;
};

export type MarketState = {
  birds: Pigeon[];
  refreshTime: number | null;
  nextRefresh: number | null;
};

export type PlayerState = {
  name: string;
  loftName: string;
  money: number;
  level: number;
  xp: number;
  totalCompetitions: number;
  totalWins: number;
  bestScore: number;
  totalMoneyEarned: number;
  joinedAt: number;
  marketSpent: number;
};

export type GameState = {
  hasSave: boolean;
  player: PlayerState;
  pigeons: Pigeon[];
  market: MarketState;
  achievements: string[];
  settings: {
    soundEnabled: boolean;
    vibrationEnabled: boolean;
  };
  lastLevelUp: number | null;
};

export type Weather = {
  name: string;
  urdu: string;
  icon: string;
  modifier: number;
  note: string;
};

export type CompetitionResult = {
  pigeonId: string;
  pigeonName: string;
  breed: BreedKey;
  hours: number;
  returned: boolean;
};

export type LeaderboardRow = {
  name: string;
  city: string;
  score: number;
  prize: number;
  isPlayer?: boolean;
};
