import { BREEDS, PLAYER_LEVELS, WEATHERS } from './data';
import {
  BreedKey,
  CompetitionResult,
  GameState,
  Gender,
  LeaderboardRow,
  Pigeon,
  StatKey,
  Weather,
} from './types';

const common: BreedKey[] = ['Teddy', 'Lahori', 'Lakha'];
const uncommon: BreedKey[] = ['Qasoori', 'Kamghar', 'Golden', 'CheenaChapra'];
const rare: BreedKey[] = ['Sialkoti', 'Kalsira', 'Salar'];
const names = ['Bijli', 'Rustam', 'Badal', 'Sheru', 'Heera', 'Sultan', 'Moti', 'Toofan', 'Noor', 'Chand'];
const eyeColors = ['orange', 'amber', 'pearl', 'dark'];
const plumage = ['white', 'silver', 'blue-bar', 'brown', 'gold', 'black', 'speckled'];

export const breedingMs = 5 * 60 * 1000;
export const incubationMs = 10 * 60 * 1000;
export const marketMs = 10 * 60 * 1000;

export function id(prefix = 'pigeon') {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

export function clamp(n: number, min = 10, max = 100) {
  return Math.max(min, Math.min(max, n));
}

export function money(n: number) {
  return `₨ ${Math.round(n).toLocaleString('ur-PK')}`;
}

export function generateStat(baseStat: number) {
  return clamp(baseStat + (Math.random() - 0.5) * 20);
}

export function calcOverallRating(pigeon: Pick<Pigeon, StatKey>) {
  return (
    pigeon.stamina * 0.3 +
    pigeon.flyHeight * 0.25 +
    pigeon.homeReturn * 0.25 +
    pigeon.agility * 0.1 +
    pigeon.heatResistance * 0.1
  );
}

export function calcFlightHours(pigeon: Pigeon, weatherModifier = 1) {
  const baseHours = (pigeon.stamina / 100) * BREEDS[pigeon.breed].maxFlightHours.max;
  const heightBonus = (pigeon.flyHeight / 100) * 1.5;
  const agBonus = (pigeon.agility / 100) * 0.5;
  const heatPenalty = weatherModifier < 1 ? (1 - pigeon.heatResistance / 100) * 2 : 0;
  return Math.max(0, baseHours + heightBonus + agBonus - heatPenalty);
}

export function calcMarketValue(pigeon: Pigeon) {
  return Math.floor(pigeon.overallRating * 25 + pigeon.competitionsWon * 200 + (pigeon.isHomeBred ? 300 : 0));
}

export function starText(rating: number) {
  const stars = Math.max(1, Math.min(5, Math.round(rating / 20)));
  return '★★★★★'.slice(0, stars) + '☆☆☆☆☆'.slice(stars);
}

export function getLevel(xp: number) {
  return [...PLAYER_LEVELS].reverse().find((level) => xp >= level.xpRequired) ?? PLAYER_LEVELS[0];
}

export function nextLevel(xp: number) {
  return PLAYER_LEVELS.find((level) => xp < level.xpRequired) ?? PLAYER_LEVELS[PLAYER_LEVELS.length - 1];
}

export function generatePigeonFromBreed(breed: BreedKey, gender?: Gender, homeBred = false): Pigeon {
  const breedData = BREEDS[breed];
  const pigeon = {
    id: id(),
    name: names[Math.floor(Math.random() * names.length)],
    breed,
    gender: gender ?? (Math.random() < 0.5 ? 'male' : 'female'),
    age: 1,
    generation: homeBred ? 2 : 1,
    isHomeBred: homeBred,
    stamina: generateStat(breedData.baseStats.stamina),
    flyHeight: generateStat(breedData.baseStats.flyHeight),
    homeReturn: generateStat(breedData.baseStats.homeReturn),
    agility: generateStat(breedData.baseStats.agility),
    heatResistance: generateStat(breedData.baseStats.heatResistance),
    overallRating: 0,
    flightPotential: 0,
    competitionScore: 0,
    isInLoft: true,
    isPaired: false,
    pairedWithId: null,
    isBreeding: false,
    breedingStartTime: null,
    isIncubating: false,
    eggLaidTime: null,
    hatchTime: null,
    juvenileUntilCompetitions: homeBred ? 1 : 0,
    competitionsEntered: 0,
    competitionsWon: 0,
    totalFlightHours: 0,
    plumageColor: plumage[Math.floor(Math.random() * plumage.length)],
    eyeColor: eyeColors[Math.floor(Math.random() * eyeColors.length)],
    purchasePrice: 0,
    marketValue: 0,
  } satisfies Pigeon;
  pigeon.overallRating = calcOverallRating(pigeon);
  pigeon.flightPotential = calcFlightHours(pigeon);
  pigeon.marketValue = calcMarketValue(pigeon);
  return pigeon;
}

function pick<T>(items: T[]) {
  return items[Math.floor(Math.random() * items.length)];
}

export function generateMarket(playerLevel: number) {
  const numBirds = 8 + Math.floor(playerLevel / 2);
  const birds = Array.from({ length: numBirds }, () => {
    const rarityRoll = Math.random();
    let breed: BreedKey;
    if (rarityRoll < 0.1 + playerLevel * 0.02) breed = pick(rare);
    else if (rarityRoll < 0.4 + playerLevel * 0.01) breed = pick(uncommon);
    else breed = pick(common);
    const pigeon = generatePigeonFromBreed(breed);
    const basePrice = BREEDS[breed].basePrice;
    const price = Math.floor(basePrice.min + Math.random() * (basePrice.max - basePrice.min));
    pigeon.purchasePrice = price;
    pigeon.marketValue = calcMarketValue(pigeon);
    return pigeon;
  });
  const now = Date.now();
  return { birds, refreshTime: now, nextRefresh: now + marketMs };
}

export function calculateOffspringStat(dadStat: number, momStat: number, generationBonus: number) {
  const parentAvg = dadStat * 0.5 + momStat * 0.5;
  const variance = (Math.random() - 0.5) * 16;
  const genBonus = Math.min(generationBonus * 0.5, 5);
  const mutation = Math.random() < 0.1 ? (Math.random() - 0.5) * 30 : 0;
  return clamp(parentAvg + variance + genBonus + mutation);
}

export function breedPair(dad: Pigeon, mom: Pigeon): Pigeon[] {
  const generation = Math.max(dad.generation, mom.generation) + 1;
  const genBonus = generation - 1;
  return [0, 1].map(() => {
    const breed = Math.random() < 0.5 ? dad.breed : mom.breed;
    const chick = generatePigeonFromBreed(breed, undefined, true);
    chick.name = `${pick(['Nanha', 'Shahbaz', 'Umeed', 'Laal'])} ${pick(names)}`;
    chick.generation = generation;
    chick.fatherBreed = dad.breed;
    chick.motherBreed = mom.breed;
    chick.stamina = calculateOffspringStat(dad.stamina, mom.stamina, genBonus);
    chick.flyHeight = calculateOffspringStat(dad.flyHeight, mom.flyHeight, genBonus);
    chick.homeReturn = calculateOffspringStat(dad.homeReturn, mom.homeReturn, genBonus);
    chick.agility = calculateOffspringStat(dad.agility, mom.agility, genBonus);
    chick.heatResistance = calculateOffspringStat(dad.heatResistance, mom.heatResistance, genBonus);
    chick.overallRating = calcOverallRating(chick);
    chick.flightPotential = calcFlightHours(chick);
    chick.marketValue = calcMarketValue(chick);
    return chick;
  });
}

export function defaultSaveState(): GameState {
  return {
    hasSave: false,
    player: {
      name: '',
      loftName: '',
      money: 10000,
      level: 1,
      xp: 0,
      totalCompetitions: 0,
      totalWins: 0,
      bestScore: 0,
      totalMoneyEarned: 0,
      joinedAt: Date.now(),
      marketSpent: 0,
    },
    pigeons: [],
    market: { birds: [], refreshTime: null, nextRefresh: null },
    achievements: [],
    settings: { soundEnabled: true, vibrationEnabled: true },
    lastLevelUp: null,
  };
}

export function recoverTimers(state: GameState) {
  const now = Date.now();
  const chicks: Pigeon[] = [];
  const updated = state.pigeons.map((pigeon) => {
    const next = { ...pigeon };
    if (next.isBreeding && next.breedingStartTime && now - next.breedingStartTime >= breedingMs) {
      next.isBreeding = false;
      next.isIncubating = true;
      next.eggLaidTime = next.breedingStartTime + breedingMs;
      next.hatchTime = next.eggLaidTime + incubationMs;
    }
    if (next.isIncubating && next.hatchTime && now >= next.hatchTime) {
      const mate = state.pigeons.find((bird) => bird.id === next.pairedWithId);
      if (mate && next.gender === 'male') chicks.push(...breedPair(next, mate));
      next.isIncubating = false;
      next.isPaired = false;
      next.pairedWithId = null;
      next.eggLaidTime = null;
      next.hatchTime = null;
    }
    next.overallRating = calcOverallRating(next);
    next.flightPotential = calcFlightHours(next);
    next.marketValue = calcMarketValue(next);
    return next;
  });
  return { ...state, pigeons: [...updated, ...chicks] };
}

export function getPigeonStatus(pigeon: Pigeon) {
  if (pigeon.isBreeding) return 'Breeding';
  if (pigeon.isIncubating) return 'Incubating';
  if (pigeon.juvenileUntilCompetitions > 0) return 'Juvenile';
  return 'Ready';
}

export function randomWeather(): Weather {
  return pick(WEATHERS);
}

export function generateBotScore(playerLevel: number, botIndex: number) {
  const baseDifficulty = 5 + playerLevel * 2;
  const variance = (Math.random() - 0.5) * 4;
  const multiplier = [0.6, 0.75, 0.85, 0.95, 1.1 + Math.max(0, playerLevel - 5) * 0.08][botIndex];
  return Math.max(1, baseDifficulty * multiplier + variance);
}

export function generateBots(playerLevel: number): LeaderboardRow[] {
  const namesByLevel =
    playerLevel >= 6
      ? ['Ustad Zafar', 'Malik Arshad', 'Ch. Irfan', 'Ustad Barkat', 'National Kabootar Baaz']
      : ['Ustad Tariq', 'Malik Arshad', 'Ch. Irfan', 'Bhai Nadeem', 'Ustad Barkat'];
  const cities = ['Lahore', 'Sialkot', 'Faisalabad', 'Rawalpindi', 'Kasur'];
  return namesByLevel.map((name, index) => ({
    name,
    city: cities[index],
    score: generateBotScore(playerLevel, index),
    prize: 0,
  }));
}

export function simulateCompetition(selected: Pigeon[], weather: Weather): CompetitionResult[] {
  return selected.map((pigeon) => {
    const returned = Math.random() < pigeon.homeReturn / 100;
    const jitter = 0.85 + Math.random() * 0.3;
    return {
      pigeonId: pigeon.id,
      pigeonName: pigeon.name,
      breed: pigeon.breed,
      hours: returned ? calcFlightHours(pigeon, weather.modifier) * jitter : 0,
      returned,
    };
  });
}

export function assignPrizes(rows: LeaderboardRow[], topPrize: number) {
  return rows
    .sort((a, b) => b.score - a.score)
    .map((row, index) => ({
      ...row,
      prize: index === 0 ? topPrize : index === 1 ? Math.floor(topPrize * 0.4) : index === 2 ? Math.floor(topPrize * 0.2) : 0,
    }));
}

export function competitionPrize(size: number) {
  if (size === 3) return 8000;
  if (size === 5) return 15000;
  return 25000;
}
