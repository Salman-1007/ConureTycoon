import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import React from 'react';
import { ImageBackground, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';

import { backgroundImages, pigeonImages } from '@/game/assets';
import { BREEDS, palette, statLabels } from '@/game/data';
import { getPigeonStatus, money, starText } from '@/game/engine';
import { Pigeon, StatKey } from '@/game/types';

export function Page({ children }: { children: React.ReactNode }) {
  return <View style={styles.page}>{children}</View>;
}

export function Header({ title, subtitle, right }: { title: string; subtitle?: string; right?: React.ReactNode }) {
  return (
    <View style={styles.header}>
      <View style={{ flex: 1 }}>
        <Text style={styles.urdu}>{title}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>
      {right}
    </View>
  );
}

export function WoodCard({ children, style }: { children: React.ReactNode; style?: object }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function ImagePanel({
  image,
  children,
  style,
}: {
  image: keyof typeof backgroundImages;
  children: React.ReactNode;
  style?: object;
}) {
  return (
    <ImageBackground source={backgroundImages[image]} style={[styles.imagePanel, style]} imageStyle={styles.imagePanelImage} resizeMode="cover">
      <View style={styles.imageOverlay}>{children}</View>
    </ImageBackground>
  );
}

export function BrassButton({
  label,
  onPress,
  disabled,
  icon,
  danger,
}: {
  label: string;
  onPress?: () => void;
  disabled?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
  danger?: boolean;
}) {
  return (
    <Pressable
      onPress={disabled ? undefined : onPress}
      style={({ pressed }) => [styles.button, danger && styles.dangerButton, disabled && styles.disabled, pressed && styles.pressed]}>
      {icon ? <Ionicons name={icon} size={16} color={disabled ? palette.muted : palette.goldLight} /> : null}
      <Text style={[styles.buttonText, disabled && { color: palette.muted }]}>{label}</Text>
    </Pressable>
  );
}

export function Badge({ label, tone = 'gold' }: { label: string; tone?: 'gold' | 'green' | 'red' | 'sky' }) {
  const colors = { gold: palette.gold, green: palette.green, red: palette.red, sky: palette.sky };
  return (
    <View style={[styles.badge, { borderColor: colors[tone] }]}>
      <Text style={[styles.badgeText, { color: colors[tone] }]}>{label}</Text>
    </View>
  );
}

export function BreedMedallion({ pigeon, size = 74 }: { pigeon: Pigeon; size?: number }) {
  const breed = BREEDS[pigeon.breed];
  const [failed, setFailed] = React.useState(false);
  const source = pigeonImages[pigeon.breed];
  return (
    <View style={[styles.medallion, { width: size, height: size, backgroundColor: breed.color }]}>
      {source && !failed ? (
        <Image source={source} style={StyleSheet.absoluteFill} contentFit="cover" onError={() => setFailed(true)} />
      ) : (
        <>
          <Text style={{ fontSize: size * 0.42 }}>🕊️</Text>
          <Text numberOfLines={1} style={styles.medallionText}>
            {breed.urduName}
          </Text>
        </>
      )}
      {source && !failed ? (
        <View style={styles.photoLabel}>
          <Text numberOfLines={1} style={styles.photoLabelText}>
            {breed.urduName}
          </Text>
        </View>
      ) : null}
    </View>
  );
}

export function StatBar({ label, value }: { label: string; value: number }) {
  return (
    <View style={styles.statRow}>
      <Text style={styles.statLabel}>{label}</Text>
      <View style={styles.statTrack}>
        <View style={[styles.statFill, { width: `${Math.max(4, Math.round(value))}%` }]} />
      </View>
      <Text style={styles.statValue}>{Math.round(value)}</Text>
    </View>
  );
}

export function PigeonCard({ pigeon, onPress, selected }: { pigeon: Pigeon; onPress?: () => void; selected?: boolean }) {
  const status = getPigeonStatus(pigeon);
  return (
    <Pressable onPress={onPress} style={[styles.pigeonCard, selected && styles.selectedCard]}>
      <BreedMedallion pigeon={pigeon} />
      <View style={{ flex: 1, minWidth: 0 }}>
        <View style={styles.rowBetween}>
          <Text numberOfLines={1} style={styles.pigeonName}>
            {pigeon.name}
          </Text>
          <Text style={styles.gender}>{pigeon.gender === 'male' ? '♂' : '♀'}</Text>
        </View>
        <Text style={styles.muted}>
          {BREEDS[pigeon.breed].name} · Gen {pigeon.generation}
        </Text>
        <Text style={styles.stars}>{starText(pigeon.overallRating)}</Text>
        <View style={styles.rowBetween}>
          <Badge label={status} tone={status === 'Ready' ? 'green' : status === 'Juvenile' ? 'sky' : 'gold'} />
          <Text style={styles.rating}>{Math.round(pigeon.overallRating)}</Text>
        </View>
      </View>
    </Pressable>
  );
}

export function PigeonDetailSheet({
  pigeon,
  visible,
  onClose,
  onRename,
  onSell,
  onPair,
}: {
  pigeon: Pigeon | null;
  visible: boolean;
  onClose: () => void;
  onRename: (name: string) => void;
  onSell: () => void;
  onPair: () => void;
}) {
  const [name, setName] = React.useState('');
  React.useEffect(() => setName(pigeon?.name ?? ''), [pigeon]);
  if (!pigeon) return null;
  const breed = BREEDS[pigeon.breed];
  const statKeys: StatKey[] = ['stamina', 'flyHeight', 'homeReturn', 'agility', 'heatResistance'];
  return (
    <Modal animationType="slide" transparent visible={visible} onRequestClose={onClose}>
      <Pressable style={styles.scrim} onPress={onClose} />
      <View style={styles.sheet}>
        <View style={styles.sheetHandle} />
        <View style={styles.detailHero}>
          <BreedMedallion pigeon={pigeon} size={96} />
          <View style={{ flex: 1 }}>
            <Text style={styles.detailTitle}>{breed.urduName}</Text>
            <Text style={styles.detailName}>{breed.name}</Text>
            <Text style={styles.muted}>{breed.origin} · {breed.rarity}</Text>
          </View>
        </View>
        <TextInput value={name} onChangeText={setName} onSubmitEditing={() => onRename(name)} style={styles.input} />
        <Text style={styles.description}>{breed.description}</Text>
        {statKeys.map((key) => (
          <StatBar key={key} label={statLabels[key]} value={pigeon[key]} />
        ))}
        <Text style={styles.description}>
          Lineage: {pigeon.isHomeBred ? `Father ${pigeon.fatherBreed} | Mother ${pigeon.motherBreed}` : 'Market-bought foundation bird'}
        </Text>
        <Text style={styles.description}>
          Flights: {pigeon.competitionsEntered} entered · {pigeon.competitionsWon} won · {pigeon.totalFlightHours.toFixed(1)} hrs
        </Text>
        <View style={styles.actionRow}>
          <BrassButton label="Pair" icon="heart" onPress={onPair} disabled={getPigeonStatus(pigeon) !== 'Ready'} />
          <BrassButton label={money(pigeon.marketValue)} icon="cash" onPress={onSell} danger />
          <BrassButton label="Rename" icon="create" onPress={() => onRename(name)} />
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: palette.bg,
    padding: 16,
    gap: 14,
  },
  header: {
    paddingTop: 44,
    paddingBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  urdu: {
    color: palette.goldLight,
    fontFamily: 'serif',
    fontSize: 30,
    fontWeight: '700',
  },
  subtitle: {
    color: palette.muted,
    fontSize: 13,
    marginTop: 3,
  },
  card: {
    backgroundColor: palette.card,
    borderColor: palette.gold,
    borderWidth: 1.5,
    borderRadius: 8,
    padding: 14,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  imagePanel: {
    borderRadius: 8,
    overflow: 'hidden',
    borderColor: palette.gold,
    borderWidth: 1.5,
    backgroundColor: palette.card,
  },
  imagePanelImage: {
    borderRadius: 8,
  },
  imageOverlay: {
    flex: 1,
    minHeight: 120,
    backgroundColor: 'rgba(26,17,8,0.48)',
    padding: 16,
  },
  button: {
    minHeight: 42,
    borderRadius: 6,
    borderColor: palette.gold,
    borderWidth: 1.5,
    backgroundColor: palette.bg2,
    paddingHorizontal: 14,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 7,
  },
  pressed: {
    transform: [{ translateY: 1 }],
    opacity: 0.86,
  },
  disabled: {
    opacity: 0.45,
  },
  dangerButton: {
    borderColor: palette.red,
  },
  buttonText: {
    color: palette.goldLight,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0,
  },
  badge: {
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '800',
  },
  medallion: {
    borderRadius: 8,
    borderWidth: 1,
    borderColor: palette.goldLight,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  medallionText: {
    color: palette.cream,
    fontSize: 10,
    fontWeight: '800',
    maxWidth: '90%',
  },
  photoLabel: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(20,12,5,0.72)',
    paddingVertical: 3,
    paddingHorizontal: 5,
  },
  photoLabelText: {
    color: palette.cream,
    textAlign: 'center',
    fontSize: 10,
    fontWeight: '900',
  },
  statRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
  },
  statLabel: {
    width: 42,
    color: palette.muted,
    fontSize: 11,
    fontWeight: '800',
  },
  statTrack: {
    flex: 1,
    height: 8,
    backgroundColor: palette.bg2,
    borderRadius: 8,
    overflow: 'hidden',
  },
  statFill: {
    height: '100%',
    backgroundColor: palette.goldLight,
  },
  statValue: {
    width: 28,
    color: palette.cream,
    fontVariant: ['tabular-nums'],
    textAlign: 'right',
  },
  pigeonCard: {
    width: '48%',
    backgroundColor: palette.card,
    borderColor: palette.gold,
    borderWidth: 1,
    borderRadius: 8,
    padding: 10,
    gap: 9,
    marginBottom: 12,
  },
  selectedCard: {
    borderColor: palette.goldLight,
    borderWidth: 2,
  },
  rowBetween: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  pigeonName: {
    color: palette.cream,
    fontSize: 16,
    fontWeight: '800',
    flex: 1,
  },
  gender: {
    color: palette.goldLight,
    fontSize: 18,
  },
  muted: {
    color: palette.muted,
    fontSize: 12,
  },
  stars: {
    color: palette.goldLight,
    fontSize: 12,
    marginVertical: 4,
  },
  rating: {
    color: palette.cream,
    fontWeight: '900',
  },
  scrim: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
  },
  sheet: {
    backgroundColor: palette.bg2,
    borderTopColor: palette.gold,
    borderTopWidth: 2,
    padding: 18,
    paddingBottom: 28,
  },
  sheetHandle: {
    alignSelf: 'center',
    width: 46,
    height: 4,
    borderRadius: 99,
    backgroundColor: palette.gold,
    marginBottom: 14,
  },
  detailHero: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginBottom: 12,
  },
  detailTitle: {
    color: palette.goldLight,
    fontSize: 28,
    fontFamily: 'serif',
  },
  detailName: {
    color: palette.cream,
    fontSize: 20,
    fontWeight: '900',
  },
  description: {
    color: palette.cream,
    lineHeight: 19,
    marginTop: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: palette.gold,
    borderRadius: 6,
    color: palette.cream,
    paddingHorizontal: 12,
    minHeight: 42,
    backgroundColor: palette.bg,
  },
  actionRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 16,
  },
});
